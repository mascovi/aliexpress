AliExpress Affiliate Telegram BOT  :

https://t.me/AliXPromotion

- get_affiliate_links
- get_promotion_products
- get_promotion_product_detail
- get_promotion_product_detail_from_link
- get_hot_products
- get_promotion_link

## How to install :

 pip install telebot
 pip install python-aliexpress-api --upgrade
 python Bot.py

 OR just install requirements.txt

 # You need : 
 - Aliexpress API 
 - Telegram bot Token
 - Tracking id (or write "default")



## How To get Aliexpress API : 
# Sign Up for an Aliexpress Account:

 If you don’t already have an account, you need to create one.

# Join the Aliexpress Affiliate Program: 
Go to the Aliexpress Affiliate Program website and sign up as an affiliate. This is necessary because the API is primarily available to affiliates.

# Apply for API Access:

Once you are an approved affiliate, log in to your affiliate account.
Navigate to the API section (usually under tools or resources).
Apply for API access by providing the necessary information about how you plan to use the API.

# Get Your API Key:

After your application is reviewed and approved, you will receive your API key.
The API key will be available in your affiliate account dashboard.

### يسمح بإستعمال هذا الكود لغرض ربحي 
# دعواتكم لنا

>> https://loudz.gumroad.com/l/cjsxvm
